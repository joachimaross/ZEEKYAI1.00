"""
Zeeky AI Secure Backend Server
Created by Joachima Ross Jr
Copyright 2025 Zeeky AI - All Rights Reserved

SECURITY FEATURES:
- API keys stored as environment variables
- Rate limiting and request validation
- CORS protection
- Input sanitization
- Session management
- Error handling without exposing sensitive data
"""

import os
import time
import json
import hashlib
from datetime import datetime, timedelta
from flask import Flask, request, jsonify
from flask_cors import CORS
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
import openai
import google.generativeai as genai
from werkzeug.exceptions import BadRequest
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)

# CORS configuration - restrict to your domain in production
CORS(app, origins=[
    "https://zeekyai.netlify.app",
    "https://joachimaross.github.io",
    "http://localhost:3000",  # For development
    "http://127.0.0.1:3000"   # For development
])

# Rate limiting
limiter = Limiter(
    app,
    key_func=get_remote_address,
    default_limits=["100 per hour", "10 per minute"]
)

# Secure configuration from environment variables
class Config:
    # NEVER put real API keys in code - use environment variables
    OPENAI_API_KEY = os.getenv('OPENAI_API_KEY', '')
    GOOGLE_API_KEY = os.getenv('GOOGLE_API_KEY', '')
    SECRET_KEY = os.getenv('SECRET_KEY', 'your-secret-key-here')
    MAX_MESSAGE_LENGTH = 4000
    SESSION_TIMEOUT = 3600  # 1 hour
    
    # Rate limiting
    REQUESTS_PER_MINUTE = 10
    REQUESTS_PER_HOUR = 100

# Initialize AI clients securely
if Config.OPENAI_API_KEY:
    openai.api_key = Config.OPENAI_API_KEY

if Config.GOOGLE_API_KEY:
    genai.configure(api_key=Config.GOOGLE_API_KEY)

# Session storage (use Redis in production)
sessions = {}

def validate_session(session_id):
    """Validate session and check timeout"""
    if not session_id or session_id not in sessions:
        return False
    
    session = sessions[session_id]
    if datetime.now() - session['created'] > timedelta(seconds=Config.SESSION_TIMEOUT):
        del sessions[session_id]
        return False
    
    return True

def sanitize_input(text):
    """Sanitize user input to prevent injection attacks"""
    if not isinstance(text, str):
        return ""
    
    # Remove potentially dangerous content
    sanitized = text.strip()
    sanitized = sanitized.replace('<', '&lt;').replace('>', '&gt;')
    sanitized = sanitized.replace('javascript:', '')
    sanitized = sanitized.replace('data:', '')
    
    return sanitized[:Config.MAX_MESSAGE_LENGTH]

def generate_session_id():
    """Generate secure session ID"""
    timestamp = str(time.time())
    random_data = os.urandom(16).hex()
    return hashlib.sha256((timestamp + random_data).encode()).hexdigest()[:32]

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'version': '1.0.0'
    })

@app.route('/api/session', methods=['POST'])
@limiter.limit("5 per minute")
def create_session():
    """Create new session"""
    session_id = generate_session_id()
    sessions[session_id] = {
        'created': datetime.now(),
        'requests': 0,
        'last_request': datetime.now()
    }
    
    return jsonify({
        'session_id': session_id,
        'expires_in': Config.SESSION_TIMEOUT
    })

@app.route('/api/chat', methods=['POST'])
@limiter.limit("10 per minute")
def chat():
    """Secure chat endpoint"""
    try:
        # Validate request
        if not request.is_json:
            raise BadRequest("Content-Type must be application/json")
        
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['message', 'session_id']
        for field in required_fields:
            if field not in data:
                raise BadRequest(f"Missing required field: {field}")
        
        # Validate session
        session_id = data['session_id']
        if not validate_session(session_id):
            return jsonify({'error': 'Invalid or expired session'}), 401
        
        # Sanitize input
        message = sanitize_input(data['message'])
        if not message:
            raise BadRequest("Invalid message")
        
        model = data.get('model', 'intelligent')
        personality = data.get('personality', 'business')
        
        # Update session
        sessions[session_id]['requests'] += 1
        sessions[session_id]['last_request'] = datetime.now()
        
        # Generate response
        response = generate_ai_response(message, model, personality)
        
        return jsonify({
            'response': response,
            'model': model,
            'personality': personality,
            'timestamp': datetime.now().isoformat()
        })
        
    except BadRequest as e:
        logger.warning(f"Bad request: {e}")
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        logger.error(f"Chat error: {e}")
        return jsonify({'error': 'Internal server error'}), 500

def generate_ai_response(message, model, personality):
    """Generate AI response with fallback"""
    try:
        # Personality prompts
        personalities = {
            'business': "You are a business expert providing professional advice.",
            'creative': "You are a creative genius inspiring innovation.",
            'tech': "You are a technical expert providing coding solutions.",
            'coach': "You are a life coach providing motivational guidance."
        }
        
        system_prompt = personalities.get(personality, personalities['business'])
        system_prompt += "\n\nYou are Zeeky AI, created by Joachima Ross Jr. Be helpful and accurate."
        
        # Try OpenAI first
        if model == 'gpt-4' and Config.OPENAI_API_KEY:
            try:
                response = openai.ChatCompletion.create(
                    model="gpt-4-turbo-preview",
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": message}
                    ],
                    max_tokens=2048,
                    temperature=0.7
                )
                return response.choices[0].message.content
            except Exception as e:
                logger.warning(f"OpenAI error: {e}")
        
        # Try Gemini
        if model == 'gemini' and Config.GOOGLE_API_KEY:
            try:
                model_instance = genai.GenerativeModel('gemini-pro')
                response = model_instance.generate_content(f"{system_prompt}\n\nUser: {message}")
                return response.text
            except Exception as e:
                logger.warning(f"Gemini error: {e}")
        
        # Fallback to intelligent response
        return generate_intelligent_response(message, personality)
        
    except Exception as e:
        logger.error(f"Response generation error: {e}")
        return generate_fallback_response()

def generate_intelligent_response(message, personality):
    """Generate intelligent fallback response"""
    lower_message = message.lower()
    
    if 'zeeky' in lower_message or 'joachima' in lower_message:
        return """Hello! I'm Zeeky AI, created by Joachima Ross Jr, CEO and founder of Zeeky AI. 

I'm designed to revolutionize human-AI interaction with advanced features including:
• 50+ specialized AI personalities
• Photorealistic avatar technology
• Advanced voice recognition and synthesis
• Multi-model AI integration
• Real-time analytics and automation
• Smart home integration
• Business intelligence tools

How can I assist you today?"""
    
    if 'business' in lower_message or 'startup' in lower_message:
        return """As your business expert, I can help you with:
• Business plan development
• Market analysis and research
• Financial strategy and planning
• Marketing and sales strategies
• Operations and scaling

What specific business challenge would you like to tackle?"""
    
    if 'code' in lower_message or 'programming' in lower_message:
        return """As your tech wizard, I can assist with:
• Web development (HTML, CSS, JavaScript, React, Python)
• Mobile app development
• Backend systems and APIs
• AI/ML integration
• Code review and optimization

What programming project are you working on?"""
    
    return f"""Thank you for your message! I'm Zeeky AI, your advanced AI assistant.

I'm currently in {personality} mode and can help you with a wide range of tasks including business strategy, software development, creative writing, and personal development.

How can I assist you today?"""

def generate_fallback_response():
    """Generate safe fallback response"""
    return """I apologize, but I'm experiencing a temporary issue. However, as Zeeky AI, I'm still here to help!

I can assist you with:
• Business planning and strategy
• Software development and coding
• Creative writing and content creation
• Personal development and coaching

Please try rephrasing your question or contact support if the issue persists.

Contact: zeekyai@hotmail.com | Phone: 773-457-9882"""

if __name__ == '__main__':
    # Development server - use proper WSGI server in production
    app.run(debug=False, host='0.0.0.0', port=int(os.getenv('PORT', 5000)))
