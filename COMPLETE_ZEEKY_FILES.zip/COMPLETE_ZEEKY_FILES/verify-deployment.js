/**
 * Zeeky AI Deployment Verification Script
 * Created by Joachima Ross Jr
 * Copyright 2025 Zeeky AI - All Rights Reserved
 * 
 * This script verifies all files are ready for production deployment
 */

const fs = require('fs');
const path = require('path');

console.log('🚀 Zeeky AI Deployment Verification');
console.log('=====================================');

// Required files for production deployment
const requiredFiles = [
    // Core Interface Files
    'index.html',
    'chat-interface.html',
    'master-interface.html',
    'personalities.html',
    'avatar-studio.html',
    'voice-lab.html',
    'ai-models.html',
    
    // JavaScript Engines
    'js/zeeky-ai-core.js',
    'js/voice-engine.js',
    'js/analytics-engine.js',
    'js/email-engine.js',
    
    // Backend Files
    'backend/secure-server.py',
    'backend/requirements.txt',
    'backend/main.py',
    
    // Security & Configuration
    '.env.example',
    '.gitignore',
    'SECURITY.md',
    'SECURITY_AUDIT.md',
    'DEPLOYMENT.md',
    
    // Deployment Files
    'package.json',
    'netlify.toml',
    '.github/workflows/deploy.yml',
    'README_COMPLETE.md',
    'DEPLOYMENT_CHECKLIST.md'
];

// Security checks
const securityChecks = [
    {
        name: 'API Keys Not Hardcoded',
        check: () => {
            const jsFiles = ['js/zeeky-ai-core.js', 'chat-interface.html'];
            for (const file of jsFiles) {
                if (fs.existsSync(file)) {
                    const content = fs.readFileSync(file, 'utf8');
                    if (content.includes('sk-') && !content.includes('your_key_here')) {
                        return false;
                    }
                }
            }
            return true;
        }
    },
    {
        name: 'Environment Template Exists',
        check: () => fs.existsSync('.env.example')
    },
    {
        name: 'Secure .gitignore Present',
        check: () => {
            if (!fs.existsSync('.gitignore')) return false;
            const content = fs.readFileSync('.gitignore', 'utf8');
            return content.includes('.env') && content.includes('*.key');
        }
    },
    {
        name: 'Security Documentation Complete',
        check: () => fs.existsSync('SECURITY.md') && fs.existsSync('SECURITY_AUDIT.md')
    }
];

// Feature verification
const featureChecks = [
    {
        name: 'Chat Interface with Theme Toggle',
        check: () => {
            if (!fs.existsSync('chat-interface.html')) return false;
            const content = fs.readFileSync('chat-interface.html', 'utf8');
            return content.includes('data-theme') && content.includes('toggleTheme');
        }
    },
    {
        name: 'Avatar Studio with 500+ Features',
        check: () => {
            if (!fs.existsSync('avatar-studio.html')) return false;
            const content = fs.readFileSync('avatar-studio.html', 'utf8');
            return content.includes('500+') && content.includes('customization');
        }
    },
    {
        name: 'Voice Lab with 200+ Features',
        check: () => {
            if (!fs.existsSync('voice-lab.html')) return false;
            const content = fs.readFileSync('voice-lab.html', 'utf8');
            return content.includes('200+') && content.includes('voice');
        }
    },
    {
        name: 'AI Models with 25+ Integrations',
        check: () => {
            if (!fs.existsSync('ai-models.html')) return false;
            const content = fs.readFileSync('ai-models.html', 'utf8');
            return content.includes('25+') && content.includes('models');
        }
    },
    {
        name: '50+ AI Personalities',
        check: () => {
            if (!fs.existsSync('personalities.html')) return false;
            const content = fs.readFileSync('personalities.html', 'utf8');
            return content.includes('50+') && content.includes('personalities');
        }
    }
];

// Run verification
let allPassed = true;

console.log('\n📁 File Verification:');
console.log('=====================');

for (const file of requiredFiles) {
    const exists = fs.existsSync(file);
    const status = exists ? '✅' : '❌';
    console.log(`${status} ${file}`);
    if (!exists) allPassed = false;
}

console.log('\n🔒 Security Verification:');
console.log('=========================');

for (const check of securityChecks) {
    const passed = check.check();
    const status = passed ? '✅' : '❌';
    console.log(`${status} ${check.name}`);
    if (!passed) allPassed = false;
}

console.log('\n🎯 Feature Verification:');
console.log('========================');

for (const check of featureChecks) {
    const passed = check.check();
    const status = passed ? '✅' : '❌';
    console.log(`${status} ${check.name}`);
    if (!passed) allPassed = false;
}

// Final verification
console.log('\n🎉 Final Verification:');
console.log('======================');

if (allPassed) {
    console.log('✅ ALL CHECKS PASSED!');
    console.log('🚀 Zeeky AI is ready for production deployment!');
    console.log('');
    console.log('📋 Next Steps:');
    console.log('1. Upload all files to GitHub');
    console.log('2. Set up environment variables');
    console.log('3. Deploy to Netlify');
    console.log('4. Configure backend (optional)');
    console.log('5. Go live!');
    console.log('');
    console.log('📞 Support: zeekyai@hotmail.com | 773-457-9882');
    console.log('👨‍💼 CEO: Joachima Ross Jr');
    console.log('🌐 Website: https://zeekyai.netlify.app');
} else {
    console.log('❌ SOME CHECKS FAILED!');
    console.log('Please review the failed items above and fix them before deployment.');
    console.log('');
    console.log('📞 Need help? Contact: zeekyai@hotmail.com | 773-457-9882');
}

console.log('\n=====================================');
console.log('© 2025 Zeeky AI. Created by Joachima Ross Jr');
console.log('=====================================');

// Exit with appropriate code
process.exit(allPassed ? 0 : 1);
