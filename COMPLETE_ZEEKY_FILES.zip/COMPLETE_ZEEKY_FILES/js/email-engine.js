/**
 * Zeeky AI Email Engine - Email Integration & Automation
 * © 2025 Zeeky AI. All Rights Reserved.
 * Created by Joachima Ross Jr, CEO & Founder
 * Contact: zeekyai@hotmail.com | (773) 457-9882
 */

class ZeekyEmailEngine {
    constructor() {
        this.emailConfig = {
            adminEmail: 'zeekyai@hotmail.com',
            supportEmail: 'support@zeekyai.com',
            noreplyEmail: 'noreply@zeekyai.com',
            ceoEmail: 'joachima@zeekyai.com'
        };
        
        this.templates = this.initializeTemplates();
        this.emailQueue = [];
        this.isProcessing = false;
    }

    initializeTemplates() {
        return {
            welcome: {
                subject: '🚀 Welcome to Zeeky AI - Your AI Journey Begins!',
                template: this.getWelcomeTemplate()
            },
            contactForm: {
                subject: '📧 New Contact Form Submission - Zeeky AI',
                template: this.getContactFormTemplate()
            },
            passwordReset: {
                subject: '🔑 Reset Your Zeeky AI Password',
                template: this.getPasswordResetTemplate()
            },
            subscriptionConfirmation: {
                subject: '💎 Zeeky AI Subscription Confirmed',
                template: this.getSubscriptionTemplate()
            },
            paymentReceipt: {
                subject: '🧾 Payment Receipt - Zeeky AI',
                template: this.getPaymentReceiptTemplate()
            },
            supportTicket: {
                subject: '🎫 Support Ticket Created - Zeeky AI',
                template: this.getSupportTicketTemplate()
            },
            newsletter: {
                subject: '📰 Zeeky AI Updates & News',
                template: this.getNewsletterTemplate()
            }
        };
    }

    async sendEmail(type, recipient, data = {}) {
        try {
            const template = this.templates[type];
            if (!template) {
                throw new Error(`Email template '${type}' not found`);
            }

            const emailData = {
                to: recipient,
                subject: this.processTemplate(template.subject, data),
                html: this.processTemplate(template.template, data),
                type: type,
                timestamp: new Date().toISOString(),
                data: data
            };

            // Add to queue
            this.emailQueue.push(emailData);
            
            // Process queue
            this.processEmailQueue();

            return { success: true, emailId: this.generateEmailId() };

        } catch (error) {
            console.error('Email sending error:', error);
            return { success: false, error: error.message };
        }
    }

    async processEmailQueue() {
        if (this.isProcessing || this.emailQueue.length === 0) {
            return;
        }

        this.isProcessing = true;

        while (this.emailQueue.length > 0) {
            const email = this.emailQueue.shift();
            await this.sendEmailViaService(email);
            
            // Rate limiting - wait 100ms between emails
            await new Promise(resolve => setTimeout(resolve, 100));
        }

        this.isProcessing = false;
    }

    async sendEmailViaService(emailData) {
        try {
            // In production, integrate with email service (SendGrid, Mailgun, etc.)
            const response = await fetch('/api/email/send', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(emailData)
            });

            if (response.ok) {
                console.log('✅ Email sent successfully:', emailData.to);
                this.logEmailSent(emailData);
            } else {
                throw new Error('Email service error');
            }

        } catch (error) {
            console.error('❌ Email sending failed:', error);
            
            // For demo purposes, simulate email sending
            this.simulateEmailSending(emailData);
        }
    }

    simulateEmailSending(emailData) {
        console.log('📧 Email Simulation:', {
            to: emailData.to,
            subject: emailData.subject,
            type: emailData.type,
            timestamp: emailData.timestamp
        });

        // Show notification to admin
        if (emailData.type === 'contactForm') {
            this.showAdminNotification(emailData);
        }

        this.logEmailSent(emailData);
    }

    showAdminNotification(emailData) {
        // Create notification for admin
        const notification = {
            title: 'New Contact Form Submission',
            message: `From: ${emailData.data.name} (${emailData.data.email})`,
            type: 'contact',
            timestamp: new Date().toISOString(),
            data: emailData.data
        };

        // Store notification
        const notifications = JSON.parse(localStorage.getItem('zeeky_admin_notifications') || '[]');
        notifications.unshift(notification);
        
        // Keep only last 50 notifications
        if (notifications.length > 50) {
            notifications.splice(50);
        }
        
        localStorage.setItem('zeeky_admin_notifications', JSON.stringify(notifications));

        // Show browser notification if permission granted
        if (Notification.permission === 'granted') {
            new Notification('Zeeky AI - New Contact', {
                body: notification.message,
                icon: '/favicon.ico'
            });
        }
    }

    logEmailSent(emailData) {
        const logs = JSON.parse(localStorage.getItem('zeeky_email_logs') || '[]');
        logs.unshift({
            id: this.generateEmailId(),
            to: emailData.to,
            subject: emailData.subject,
            type: emailData.type,
            timestamp: emailData.timestamp,
            status: 'sent'
        });

        // Keep only last 100 email logs
        if (logs.length > 100) {
            logs.splice(100);
        }

        localStorage.setItem('zeeky_email_logs', JSON.stringify(logs));
    }

    processTemplate(template, data) {
        let processed = template;
        
        // Replace placeholders with actual data
        Object.keys(data).forEach(key => {
            const placeholder = `{{${key}}}`;
            processed = processed.replace(new RegExp(placeholder, 'g'), data[key] || '');
        });

        // Replace default placeholders
        processed = processed.replace(/{{currentYear}}/g, new Date().getFullYear());
        processed = processed.replace(/{{currentDate}}/g, new Date().toLocaleDateString());
        processed = processed.replace(/{{adminEmail}}/g, this.emailConfig.adminEmail);
        processed = processed.replace(/{{supportEmail}}/g, this.emailConfig.supportEmail);

        return processed;
    }

    generateEmailId() {
        return 'email_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }

    // Email Templates
    getWelcomeTemplate() {
        return `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #f8f9fa; padding: 20px;">
            <div style="background: linear-gradient(135deg, #667eea, #764ba2); color: white; padding: 30px; border-radius: 10px; text-align: center;">
                <h1 style="margin: 0; font-size: 2em;">🚀 Welcome to Zeeky AI!</h1>
                <p style="margin: 10px 0 0 0; font-size: 1.1em;">Your AI journey begins now</p>
            </div>
            
            <div style="background: white; padding: 30px; border-radius: 10px; margin-top: 20px;">
                <h2 style="color: #333;">Hello {{name}}!</h2>
                
                <p>Welcome to the future of AI assistance! I'm thrilled you've joined the Zeeky AI community.</p>
                
                <p><strong>What you can do now:</strong></p>
                <ul>
                    <li>💬 Chat with advanced AI models</li>
                    <li>👤 Interact with photorealistic avatars</li>
                    <li>🎤 Use voice commands and responses</li>
                    <li>🎨 Explore creative AI capabilities</li>
                </ul>
                
                <div style="text-align: center; margin: 30px 0;">
                    <a href="https://zeekyai.netlify.app/chat" style="background: linear-gradient(135deg, #667eea, #764ba2); color: white; padding: 15px 30px; text-decoration: none; border-radius: 25px; font-weight: bold;">Start Chatting Now</a>
                </div>
                
                <p>If you have any questions, feel free to reach out to me directly:</p>
                <p><strong>Joachima Ross Jr</strong><br>
                CEO & Founder, Zeeky AI<br>
                📧 {{adminEmail}}<br>
                📞 (773) 457-9882</p>
            </div>
            
            <div style="text-align: center; margin-top: 20px; color: #666; font-size: 0.9em;">
                <p>© {{currentYear}} Zeeky AI. All Rights Reserved.</p>
                <p>Created by Joachima Ross Jr</p>
            </div>
        </div>
        `;
    }

    getContactFormTemplate() {
        return `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #f8f9fa; padding: 20px;">
            <div style="background: #dc3545; color: white; padding: 20px; border-radius: 10px; text-align: center;">
                <h1 style="margin: 0;">📧 New Contact Form Submission</h1>
            </div>
            
            <div style="background: white; padding: 30px; border-radius: 10px; margin-top: 20px;">
                <h2 style="color: #333;">Contact Details:</h2>
                
                <table style="width: 100%; border-collapse: collapse;">
                    <tr>
                        <td style="padding: 10px; border-bottom: 1px solid #eee; font-weight: bold;">Name:</td>
                        <td style="padding: 10px; border-bottom: 1px solid #eee;">{{name}}</td>
                    </tr>
                    <tr>
                        <td style="padding: 10px; border-bottom: 1px solid #eee; font-weight: bold;">Email:</td>
                        <td style="padding: 10px; border-bottom: 1px solid #eee;">{{email}}</td>
                    </tr>
                    <tr>
                        <td style="padding: 10px; border-bottom: 1px solid #eee; font-weight: bold;">Company:</td>
                        <td style="padding: 10px; border-bottom: 1px solid #eee;">{{company}}</td>
                    </tr>
                    <tr>
                        <td style="padding: 10px; border-bottom: 1px solid #eee; font-weight: bold;">Subject:</td>
                        <td style="padding: 10px; border-bottom: 1px solid #eee;">{{subject}}</td>
                    </tr>
                    <tr>
                        <td style="padding: 10px; border-bottom: 1px solid #eee; font-weight: bold;">Submitted:</td>
                        <td style="padding: 10px; border-bottom: 1px solid #eee;">{{currentDate}}</td>
                    </tr>
                </table>
                
                <h3 style="color: #333; margin-top: 20px;">Message:</h3>
                <div style="background: #f8f9fa; padding: 15px; border-radius: 5px; border-left: 4px solid #667eea;">
                    {{message}}
                </div>
                
                <div style="text-align: center; margin: 30px 0;">
                    <a href="mailto:{{email}}" style="background: linear-gradient(135deg, #667eea, #764ba2); color: white; padding: 15px 30px; text-decoration: none; border-radius: 25px; font-weight: bold;">Reply to {{name}}</a>
                </div>
            </div>
        </div>
        `;
    }

    getPasswordResetTemplate() {
        return `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #f8f9fa; padding: 20px;">
            <div style="background: linear-gradient(135deg, #ffc107, #fd7e14); color: white; padding: 30px; border-radius: 10px; text-align: center;">
                <h1 style="margin: 0;">🔑 Password Reset Request</h1>
            </div>
            
            <div style="background: white; padding: 30px; border-radius: 10px; margin-top: 20px;">
                <h2 style="color: #333;">Hello {{name}},</h2>
                
                <p>We received a request to reset your Zeeky AI password. If you didn't make this request, you can safely ignore this email.</p>
                
                <div style="text-align: center; margin: 30px 0;">
                    <a href="{{resetLink}}" style="background: linear-gradient(135deg, #667eea, #764ba2); color: white; padding: 15px 30px; text-decoration: none; border-radius: 25px; font-weight: bold;">Reset My Password</a>
                </div>
                
                <p style="color: #666; font-size: 0.9em;">This link will expire in 24 hours for security reasons.</p>
                
                <p>If you're having trouble with the button above, copy and paste this URL into your browser:</p>
                <p style="word-break: break-all; color: #667eea;">{{resetLink}}</p>
            </div>
        </div>
        `;
    }

    getSubscriptionTemplate() {
        return `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #f8f9fa; padding: 20px;">
            <div style="background: linear-gradient(135deg, #28a745, #20c997); color: white; padding: 30px; border-radius: 10px; text-align: center;">
                <h1 style="margin: 0;">💎 Subscription Confirmed!</h1>
            </div>
            
            <div style="background: white; padding: 30px; border-radius: 10px; margin-top: 20px;">
                <h2 style="color: #333;">Welcome to {{plan}} Plan!</h2>
                
                <p>Your Zeeky AI {{plan}} subscription is now active. You now have access to:</p>
                
                <ul>
                    <li>✅ Unlimited AI conversations</li>
                    <li>✅ Advanced AI models (GPT-4, Gemini)</li>
                    <li>✅ Photorealistic custom avatars</li>
                    <li>✅ Voice synthesis & emotions</li>
                    <li>✅ Priority support</li>
                </ul>
                
                <div style="text-align: center; margin: 30px 0;">
                    <a href="https://zeekyai.netlify.app/dashboard" style="background: linear-gradient(135deg, #667eea, #764ba2); color: white; padding: 15px 30px; text-decoration: none; border-radius: 25px; font-weight: bold;">Access Your Dashboard</a>
                </div>
                
                <p><strong>Billing Information:</strong></p>
                <p>Plan: {{plan}}<br>
                Amount: ${{amount}}<br>
                Next billing: {{nextBilling}}</p>
            </div>
        </div>
        `;
    }

    getPaymentReceiptTemplate() {
        return `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #f8f9fa; padding: 20px;">
            <div style="background: linear-gradient(135deg, #667eea, #764ba2); color: white; padding: 30px; border-radius: 10px; text-align: center;">
                <h1 style="margin: 0;">🧾 Payment Receipt</h1>
            </div>
            
            <div style="background: white; padding: 30px; border-radius: 10px; margin-top: 20px;">
                <h2 style="color: #333;">Payment Successful</h2>
                
                <table style="width: 100%; border-collapse: collapse; margin: 20px 0;">
                    <tr>
                        <td style="padding: 10px; border-bottom: 1px solid #eee; font-weight: bold;">Transaction ID:</td>
                        <td style="padding: 10px; border-bottom: 1px solid #eee;">{{transactionId}}</td>
                    </tr>
                    <tr>
                        <td style="padding: 10px; border-bottom: 1px solid #eee; font-weight: bold;">Plan:</td>
                        <td style="padding: 10px; border-bottom: 1px solid #eee;">{{plan}}</td>
                    </tr>
                    <tr>
                        <td style="padding: 10px; border-bottom: 1px solid #eee; font-weight: bold;">Amount:</td>
                        <td style="padding: 10px; border-bottom: 1px solid #eee;">${{amount}}</td>
                    </tr>
                    <tr>
                        <td style="padding: 10px; border-bottom: 1px solid #eee; font-weight: bold;">Date:</td>
                        <td style="padding: 10px; border-bottom: 1px solid #eee;">{{currentDate}}</td>
                    </tr>
                </table>
                
                <p>Thank you for your payment! Your subscription is now active.</p>
            </div>
        </div>
        `;
    }

    getSupportTicketTemplate() {
        return `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #f8f9fa; padding: 20px;">
            <div style="background: linear-gradient(135deg, #17a2b8, #138496); color: white; padding: 30px; border-radius: 10px; text-align: center;">
                <h1 style="margin: 0;">🎫 Support Ticket Created</h1>
            </div>
            
            <div style="background: white; padding: 30px; border-radius: 10px; margin-top: 20px;">
                <h2 style="color: #333;">Ticket #{{ticketId}}</h2>
                
                <p>Your support ticket has been created successfully. Our team will respond within 24 hours.</p>
                
                <p><strong>Issue:</strong> {{issue}}</p>
                <p><strong>Priority:</strong> {{priority}}</p>
                
                <div style="text-align: center; margin: 30px 0;">
                    <a href="{{ticketUrl}}" style="background: linear-gradient(135deg, #667eea, #764ba2); color: white; padding: 15px 30px; text-decoration: none; border-radius: 25px; font-weight: bold;">View Ticket</a>
                </div>
            </div>
        </div>
        `;
    }

    getNewsletterTemplate() {
        return `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #f8f9fa; padding: 20px;">
            <div style="background: linear-gradient(135deg, #667eea, #764ba2); color: white; padding: 30px; border-radius: 10px; text-align: center;">
                <h1 style="margin: 0;">📰 Zeeky AI Updates</h1>
            </div>
            
            <div style="background: white; padding: 30px; border-radius: 10px; margin-top: 20px;">
                <h2 style="color: #333;">{{title}}</h2>
                
                <div style="margin: 20px 0;">
                    {{content}}
                </div>
                
                <div style="text-align: center; margin: 30px 0;">
                    <a href="https://zeekyai.netlify.app" style="background: linear-gradient(135deg, #667eea, #764ba2); color: white; padding: 15px 30px; text-decoration: none; border-radius: 25px; font-weight: bold;">Visit Zeeky AI</a>
                </div>
            </div>
            
            <div style="text-align: center; margin-top: 20px; color: #666; font-size: 0.9em;">
                <p><a href="{{unsubscribeLink}}" style="color: #666;">Unsubscribe</a> | <a href="{{preferencesLink}}" style="color: #666;">Email Preferences</a></p>
            </div>
        </div>
        `;
    }

    // Public API methods
    async sendWelcomeEmail(email, name, plan = 'free') {
        return await this.sendEmail('welcome', email, { name, plan });
    }

    async sendContactFormNotification(formData) {
        return await this.sendEmail('contactForm', this.emailConfig.adminEmail, formData);
    }

    async sendPasswordReset(email, name, resetLink) {
        return await this.sendEmail('passwordReset', email, { name, resetLink });
    }

    async sendSubscriptionConfirmation(email, plan, amount, nextBilling) {
        return await this.sendEmail('subscriptionConfirmation', email, { plan, amount, nextBilling });
    }

    async sendPaymentReceipt(email, transactionId, plan, amount) {
        return await this.sendEmail('paymentReceipt', email, { transactionId, plan, amount });
    }

    getEmailLogs() {
        return JSON.parse(localStorage.getItem('zeeky_email_logs') || '[]');
    }

    getAdminNotifications() {
        return JSON.parse(localStorage.getItem('zeeky_admin_notifications') || '[]');
    }

    clearNotifications() {
        localStorage.removeItem('zeeky_admin_notifications');
    }
}

// Global instance
window.ZeekyEmail = new ZeekyEmailEngine();

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ZeekyEmailEngine;
}
