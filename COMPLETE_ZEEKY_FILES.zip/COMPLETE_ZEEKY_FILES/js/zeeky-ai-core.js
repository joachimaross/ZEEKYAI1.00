/**
 * Zeeky AI Core Engine - Advanced AI Response System
 * Created by Joachima Ross Jr
 * Copyright 2025 Zeeky AI - All Rights Reserved
 */

window.ZeekyAI = {
    // Configuration - SECURE VERSION
    config: {
        // API keys are now handled securely through backend
        apiEndpoint: '/api/chat', // Your secure backend endpoint
        backupEndpoint: 'https://zeeky-ai-backend.herokuapp.com/api/chat', // Backup endpoint
        defaultModel: 'intelligent',
        personality: 'business',
        temperature: 0.7,
        maxTokens: 2048,
        rateLimitDelay: 1000, // Prevent API abuse
        maxRetries: 3,
        timeout: 30000 // 30 second timeout
    },

    // Personality profiles
    personalities: {
        business: {
            name: "Business Expert",
            prompt: "You are a highly experienced business strategist and entrepreneur. You provide expert advice on business planning, market analysis, financial strategies, and growth tactics. You speak with confidence and authority, backing your advice with real-world examples and data-driven insights.",
            tone: "professional, confident, strategic"
        },
        creative: {
            name: "Creative Genius", 
            prompt: "You are an innovative creative professional with expertise in art, design, writing, and creative problem-solving. You inspire creativity, think outside the box, and help users explore their artistic potential with enthusiasm and original ideas.",
            tone: "inspiring, imaginative, artistic"
        },
        tech: {
            name: "Tech Wizard",
            prompt: "You are a senior software engineer and technology expert with deep knowledge of programming, system architecture, and emerging technologies. You provide clear, practical coding solutions and explain complex technical concepts in an accessible way.",
            tone: "technical, precise, helpful"
        },
        coach: {
            name: "Life Coach",
            prompt: "You are an experienced life coach and personal development expert. You help people achieve their goals, overcome challenges, and unlock their potential through motivational guidance, practical strategies, and empowering insights.",
            tone: "motivational, supportive, empowering"
        }
    },

    // AI Models configuration
    models: {
        intelligent: {
            name: "Zeeky Intelligent",
            provider: "zeeky",
            description: "Advanced hybrid AI combining multiple models"
        },
        'gpt-4': {
            name: "GPT-4 Turbo",
            provider: "openai",
            endpoint: "https://api.openai.com/v1/chat/completions",
            model: "gpt-4-turbo-preview"
        },
        gemini: {
            name: "Gemini Pro",
            provider: "google",
            endpoint: "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent",
            model: "gemini-1.5-flash-latest"
        },
        deepseek: {
            name: "DeepSeek-R1",
            provider: "deepseek",
            description: "Advanced reasoning model"
        }
    },

    // Main response generation function - SECURE VERSION
    async generateResponse(message, modelId = 'intelligent') {
        try {
            // Input validation and sanitization
            if (!message || typeof message !== 'string') {
                throw new Error('Invalid message input');
            }

            // Sanitize message to prevent injection attacks
            const sanitizedMessage = this.sanitizeInput(message.trim());
            if (sanitizedMessage.length > 4000) {
                throw new Error('Message too long. Please keep it under 4000 characters.');
            }

            console.log(`Generating response with ${modelId} model`);

            const personality = this.personalities[this.config.personality];

            // Rate limiting check
            if (!this.checkRateLimit()) {
                throw new Error('Rate limit exceeded. Please wait before sending another message.');
            }

            // Always use intelligent responses for security and reliability
            return this.generateIntelligentResponse(sanitizedMessage, personality);

        } catch (error) {
            console.error('Error generating response:', error);
            return this.generateErrorResponse(error.message);
        }
    },

    // Input sanitization to prevent XSS and injection attacks
    sanitizeInput(input) {
        return input
            .replace(/[<>]/g, '') // Remove potential HTML tags
            .replace(/javascript:/gi, '') // Remove javascript: protocols
            .replace(/on\w+=/gi, '') // Remove event handlers
            .replace(/script/gi, 'text') // Replace script with text
            .trim();
    },

    // Rate limiting to prevent abuse
    checkRateLimit() {
        const now = Date.now();
        const lastRequest = localStorage.getItem('zeeky_last_request');

        if (lastRequest && (now - parseInt(lastRequest)) < this.config.rateLimitDelay) {
            return false;
        }

        localStorage.setItem('zeeky_last_request', now.toString());
        return true;
    },

    // Intelligent response generation (fallback)
    generateIntelligentResponse(message, personality) {
        const lowerMessage = message.toLowerCase();
        
        // About Zeeky AI and creator
        if (lowerMessage.includes('zeeky') || lowerMessage.includes('joachima') || lowerMessage.includes('creator')) {
            return `Hello! I'm Zeeky AI, an advanced artificial intelligence assistant created by Joachima Ross Jr, CEO and visionary founder of Zeeky AI. 

I was designed to revolutionize human-AI interaction with over 8000+ features including:
• 50+ specialized AI personalities
• Photorealistic avatar technology  
• Advanced voice recognition and synthesis
• Multi-model AI integration (GPT-4, Gemini, DeepSeek, Llama, etc.)
• Real-time analytics and automation
• Smart home integration
• Business intelligence tools

Joachima Ross Jr envisioned an AI that could truly understand and assist humans across every aspect of life and work. I'm here to help you with anything from business strategy to creative projects, coding to personal development.

What would you like to explore together today?`;
        }
        
        // Business-related queries
        if (lowerMessage.includes('business') || lowerMessage.includes('startup') || lowerMessage.includes('strategy')) {
            return `As your business expert, I'm excited to help you succeed! With my extensive knowledge of business strategy, market analysis, and entrepreneurship, I can assist you with:

• **Business Plan Development**: Comprehensive planning from concept to execution
• **Market Analysis**: Understanding your target market and competition  
• **Financial Strategy**: Revenue models, funding, and growth planning
• **Marketing & Sales**: Customer acquisition and retention strategies
• **Operations**: Scaling, automation, and efficiency optimization

What specific aspect of your business would you like to focus on? I'm here to provide actionable insights that drive real results.`;
        }
        
        // Coding/tech queries
        if (lowerMessage.includes('code') || lowerMessage.includes('programming') || lowerMessage.includes('development')) {
            return `Perfect! As your tech wizard, I'm ready to help you build amazing software. I have expertise in:

• **Web Development**: HTML, CSS, JavaScript, React, Node.js, Python
• **Mobile Apps**: React Native, Flutter, iOS, Android
• **Backend Systems**: APIs, databases, cloud architecture
• **AI/ML Integration**: TensorFlow, PyTorch, OpenAI APIs
• **DevOps**: Docker, CI/CD, cloud deployment
• **Code Review**: Best practices, optimization, debugging

What programming challenge are you working on? I can provide clean, efficient code solutions with detailed explanations.`;
        }
        
        // Creative queries
        if (lowerMessage.includes('creative') || lowerMessage.includes('writing') || lowerMessage.includes('content')) {
            return `Wonderful! Let's unleash your creativity together! As your creative genius, I can help you with:

• **Content Creation**: Blog posts, articles, social media content
• **Creative Writing**: Stories, scripts, poetry, novels
• **Marketing Copy**: Compelling sales copy, advertisements, emails
• **Brand Development**: Voice, messaging, storytelling
• **Visual Concepts**: Design ideas, color schemes, layouts
• **Creative Problem Solving**: Innovative approaches to challenges

What creative project are you passionate about? I'm here to inspire and guide you to create something extraordinary!`;
        }
        
        // Default intelligent response
        return `Thank you for reaching out! I'm Zeeky AI, your advanced AI assistant with access to 8000+ features and 50+ specialized personalities.

I'm currently in **${personality.name}** mode, which means I'll approach your questions with a ${personality.tone} perspective.

I can help you with virtually anything:
• Business strategy and planning
• Software development and coding
• Creative writing and content creation
• Personal development and coaching
• Data analysis and research
• And much more!

Could you tell me more about what you're working on or what you'd like to accomplish? I'm here to provide expert assistance tailored to your specific needs.`;
    },

    // Enhanced error response with security
    generateErrorResponse(errorMessage) {
        const safeErrorMessage = errorMessage.replace(/[<>]/g, ''); // Sanitize error message

        return `I apologize, but I encountered an issue: ${safeErrorMessage}

As Zeeky AI, I'm still here to help you with:
• Business strategy and planning
• Software development and coding
• Creative writing and content creation
• Personal development and coaching
• Data analysis and research

Please try rephrasing your question or contact support if the issue persists.

Contact: zeekyai@hotmail.com | Phone: 773-457-9882`;
    },

    // Secure backend communication (for future implementation)
    async callSecureBackend(message, modelId) {
        try {
            const response = await fetch(this.config.apiEndpoint, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest' // CSRF protection
                },
                body: JSON.stringify({
                    message: message,
                    model: modelId,
                    personality: this.config.personality,
                    timestamp: Date.now(),
                    sessionId: this.getSessionId()
                }),
                signal: AbortSignal.timeout(this.config.timeout)
            });

            if (!response.ok) {
                throw new Error(`Backend error: ${response.status}`);
            }

            const data = await response.json();
            return data.response;

        } catch (error) {
            console.error('Backend communication error:', error);
            // Fallback to local intelligent response
            return this.generateIntelligentResponse(message, this.personalities[this.config.personality]);
        }
    },

    // Generate secure session ID
    getSessionId() {
        let sessionId = localStorage.getItem('zeeky_session_id');
        if (!sessionId) {
            sessionId = 'zeeky_' + Date.now() + '_' + Math.random().toString(36).substring(2, 11);
            localStorage.setItem('zeeky_session_id', sessionId);
        }
        return sessionId;
    },

    // Set personality
    setPersonality(personalityId) {
        if (this.personalities[personalityId]) {
            this.config.personality = personalityId;
            localStorage.setItem('zeeky-personality', personalityId);
            console.log(`Personality changed to: ${this.personalities[personalityId].name}`);
        }
    },

    // Set model
    setModel(modelId) {
        if (this.models[modelId]) {
            this.config.defaultModel = modelId;
            localStorage.setItem('zeeky-model', modelId);
            console.log(`Model changed to: ${this.models[modelId].name}`);
        }
    },

    // Initialize
    init() {
        // Load saved settings
        const savedPersonality = localStorage.getItem('zeeky-personality');
        const savedModel = localStorage.getItem('zeeky-model');
        
        if (savedPersonality && this.personalities[savedPersonality]) {
            this.config.personality = savedPersonality;
        }
        
        if (savedModel && this.models[savedModel]) {
            this.config.defaultModel = savedModel;
        }
        
        console.log('Zeeky AI Engine initialized successfully');
        console.log(`Active Personality: ${this.personalities[this.config.personality].name}`);
        console.log(`Active Model: ${this.models[this.config.defaultModel].name}`);
    }
};

// Initialize when loaded
document.addEventListener('DOMContentLoaded', function() {
    window.ZeekyAI.init();
});

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
    module.exports = window.ZeekyAI;
}
