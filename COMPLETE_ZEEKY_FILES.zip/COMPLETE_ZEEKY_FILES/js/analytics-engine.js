/**
 * Zeeky AI Analytics Engine - Real-time Analytics & Tracking
 * © 2025 Zeeky AI. All Rights Reserved.
 * Created by Joachima Ross Jr, CEO & Founder
 * Contact: zeekyai@hotmail.com | (773) 457-9882
 */

class ZeekyAnalyticsEngine {
    constructor() {
        this.sessionId = this.generateSessionId();
        this.userId = this.getUserId();
        this.startTime = new Date();
        this.events = [];
        this.metrics = {
            pageViews: 0,
            chatMessages: 0,
            voiceInteractions: 0,
            avatarInteractions: 0,
            timeSpent: 0,
            features: {},
            errors: []
        };
        
        this.initializeTracking();
        this.startHeartbeat();
    }

    generateSessionId() {
        return 'session_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }

    getUserId() {
        const user = localStorage.getItem('zeeky_user');
        if (user) {
            return JSON.parse(user).userId;
        }
        
        // Generate anonymous user ID
        let anonymousId = localStorage.getItem('zeeky_anonymous_id');
        if (!anonymousId) {
            anonymousId = 'anon_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
            localStorage.setItem('zeeky_anonymous_id', anonymousId);
        }
        return anonymousId;
    }

    initializeTracking() {
        // Track page load
        this.trackEvent('page_load', {
            url: window.location.href,
            title: document.title,
            referrer: document.referrer,
            userAgent: navigator.userAgent,
            timestamp: new Date().toISOString()
        });

        // Track page visibility changes
        document.addEventListener('visibilitychange', () => {
            if (document.hidden) {
                this.trackEvent('page_hidden');
            } else {
                this.trackEvent('page_visible');
            }
        });

        // Track clicks
        document.addEventListener('click', (event) => {
            this.trackClick(event);
        });

        // Track form submissions
        document.addEventListener('submit', (event) => {
            this.trackFormSubmission(event);
        });

        // Track errors
        window.addEventListener('error', (event) => {
            this.trackError(event.error, event.filename, event.lineno);
        });

        // Track unhandled promise rejections
        window.addEventListener('unhandledrejection', (event) => {
            this.trackError(event.reason, 'Promise rejection');
        });

        // Track page unload
        window.addEventListener('beforeunload', () => {
            this.trackEvent('page_unload', {
                timeSpent: this.getTimeSpent(),
                events: this.events.length
            });
            this.sendAnalytics();
        });
    }

    trackEvent(eventName, data = {}) {
        const event = {
            id: this.generateEventId(),
            sessionId: this.sessionId,
            userId: this.userId,
            eventName: eventName,
            data: data,
            timestamp: new Date().toISOString(),
            url: window.location.href,
            userAgent: navigator.userAgent
        };

        this.events.push(event);
        this.updateMetrics(eventName, data);

        // Send critical events immediately
        if (this.isCriticalEvent(eventName)) {
            this.sendEvent(event);
        }

        console.log('📊 Analytics Event:', eventName, data);
    }

    generateEventId() {
        return 'event_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }

    isCriticalEvent(eventName) {
        const criticalEvents = [
            'user_signup',
            'user_login',
            'payment_completed',
            'subscription_started',
            'error_occurred',
            'api_error'
        ];
        return criticalEvents.includes(eventName);
    }

    updateMetrics(eventName, data) {
        switch (eventName) {
            case 'page_load':
                this.metrics.pageViews++;
                break;
            case 'chat_message_sent':
                this.metrics.chatMessages++;
                break;
            case 'voice_interaction':
                this.metrics.voiceInteractions++;
                break;
            case 'avatar_interaction':
                this.metrics.avatarInteractions++;
                break;
            case 'feature_used':
                const feature = data.feature;
                this.metrics.features[feature] = (this.metrics.features[feature] || 0) + 1;
                break;
            case 'error_occurred':
                this.metrics.errors.push({
                    error: data.error,
                    timestamp: new Date().toISOString()
                });
                break;
        }
    }

    trackClick(event) {
        const element = event.target;
        const data = {
            tagName: element.tagName,
            className: element.className,
            id: element.id,
            text: element.textContent?.substring(0, 100),
            href: element.href,
            coordinates: {
                x: event.clientX,
                y: event.clientY
            }
        };

        this.trackEvent('click', data);
    }

    trackFormSubmission(event) {
        const form = event.target;
        const data = {
            formId: form.id,
            formAction: form.action,
            formMethod: form.method,
            fieldCount: form.elements.length
        };

        this.trackEvent('form_submission', data);
    }

    trackError(error, filename = '', lineno = 0) {
        const data = {
            error: error.toString(),
            filename: filename,
            lineno: lineno,
            stack: error.stack,
            userAgent: navigator.userAgent
        };

        this.trackEvent('error_occurred', data);
    }

    // Specific tracking methods for Zeeky AI features
    trackChatMessage(message, response, model) {
        this.trackEvent('chat_message_sent', {
            messageLength: message.length,
            responseLength: response.length,
            model: model,
            conversationId: this.sessionId
        });
    }

    trackVoiceInteraction(action, duration = 0) {
        this.trackEvent('voice_interaction', {
            action: action, // 'start_listening', 'stop_listening', 'speech_recognized', 'speech_synthesized'
            duration: duration
        });
    }

    trackAvatarInteraction(action, emotion = null) {
        this.trackEvent('avatar_interaction', {
            action: action, // 'emotion_change', 'voice_sync', 'customization'
            emotion: emotion
        });
    }

    trackFeatureUsage(feature, details = {}) {
        this.trackEvent('feature_used', {
            feature: feature,
            details: details
        });
    }

    trackUserSignup(plan, email) {
        this.trackEvent('user_signup', {
            plan: plan,
            email: email,
            source: document.referrer
        });
    }

    trackUserLogin(email, method = 'email') {
        this.trackEvent('user_login', {
            email: email,
            method: method
        });
    }

    trackPayment(plan, amount, currency = 'USD') {
        this.trackEvent('payment_completed', {
            plan: plan,
            amount: amount,
            currency: currency
        });
    }

    trackSubscription(plan, action) {
        this.trackEvent('subscription_' + action, {
            plan: plan,
            timestamp: new Date().toISOString()
        });
    }

    // Performance tracking
    trackPerformance() {
        if (window.performance) {
            const navigation = performance.getEntriesByType('navigation')[0];
            const data = {
                loadTime: navigation.loadEventEnd - navigation.loadEventStart,
                domContentLoaded: navigation.domContentLoadedEventEnd - navigation.domContentLoadedEventStart,
                firstPaint: this.getFirstPaint(),
                firstContentfulPaint: this.getFirstContentfulPaint()
            };

            this.trackEvent('performance_metrics', data);
        }
    }

    getFirstPaint() {
        const paintEntries = performance.getEntriesByType('paint');
        const firstPaint = paintEntries.find(entry => entry.name === 'first-paint');
        return firstPaint ? firstPaint.startTime : 0;
    }

    getFirstContentfulPaint() {
        const paintEntries = performance.getEntriesByType('paint');
        const firstContentfulPaint = paintEntries.find(entry => entry.name === 'first-contentful-paint');
        return firstContentfulPaint ? firstContentfulPaint.startTime : 0;
    }

    getTimeSpent() {
        return Math.round((new Date() - this.startTime) / 1000);
    }

    startHeartbeat() {
        // Send analytics data every 30 seconds
        setInterval(() => {
            this.metrics.timeSpent = this.getTimeSpent();
            this.sendAnalytics();
        }, 30000);
    }

    async sendEvent(event) {
        try {
            // In production, send to your analytics backend
            const response = await fetch('/api/analytics/event', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(event)
            });

            if (!response.ok) {
                console.warn('Failed to send analytics event');
            }
        } catch (error) {
            console.warn('Analytics error:', error);
            // Store failed events for retry
            this.storeFailedEvent(event);
        }
    }

    async sendAnalytics() {
        if (this.events.length === 0) return;

        try {
            const payload = {
                sessionId: this.sessionId,
                userId: this.userId,
                metrics: this.metrics,
                events: this.events,
                timestamp: new Date().toISOString()
            };

            // In production, send to your analytics backend
            const response = await fetch('/api/analytics/batch', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(payload)
            });

            if (response.ok) {
                // Clear sent events
                this.events = [];
            } else {
                console.warn('Failed to send analytics batch');
            }
        } catch (error) {
            console.warn('Analytics batch error:', error);
        }
    }

    storeFailedEvent(event) {
        const failedEvents = JSON.parse(localStorage.getItem('zeeky_failed_analytics') || '[]');
        failedEvents.push(event);
        
        // Keep only last 100 failed events
        if (failedEvents.length > 100) {
            failedEvents.splice(0, failedEvents.length - 100);
        }
        
        localStorage.setItem('zeeky_failed_analytics', JSON.stringify(failedEvents));
    }

    retryFailedEvents() {
        const failedEvents = JSON.parse(localStorage.getItem('zeeky_failed_analytics') || '[]');
        
        failedEvents.forEach(event => {
            this.sendEvent(event);
        });
        
        localStorage.removeItem('zeeky_failed_analytics');
    }

    // Public API for getting analytics data
    getSessionMetrics() {
        return {
            sessionId: this.sessionId,
            userId: this.userId,
            timeSpent: this.getTimeSpent(),
            metrics: this.metrics,
            eventCount: this.events.length
        };
    }

    getRealtimeStats() {
        return {
            activeUsers: 1, // This user
            totalSessions: this.getStoredSessionCount(),
            avgSessionTime: this.getAverageSessionTime(),
            topFeatures: this.getTopFeatures(),
            errorRate: this.getErrorRate()
        };
    }

    getStoredSessionCount() {
        const sessions = JSON.parse(localStorage.getItem('zeeky_session_count') || '0');
        return sessions + 1;
    }

    getAverageSessionTime() {
        const times = JSON.parse(localStorage.getItem('zeeky_session_times') || '[]');
        if (times.length === 0) return 0;
        return times.reduce((a, b) => a + b, 0) / times.length;
    }

    getTopFeatures() {
        const features = Object.entries(this.metrics.features);
        return features.sort((a, b) => b[1] - a[1]).slice(0, 5);
    }

    getErrorRate() {
        const totalEvents = this.events.length;
        const errorEvents = this.metrics.errors.length;
        return totalEvents > 0 ? (errorEvents / totalEvents) * 100 : 0;
    }

    // Integration with Google Analytics
    initializeGoogleAnalytics(trackingId) {
        if (typeof gtag !== 'undefined') {
            gtag('config', trackingId, {
                custom_map: {
                    'custom_parameter_1': 'zeeky_user_id',
                    'custom_parameter_2': 'zeeky_session_id'
                }
            });
        }
    }

    sendToGoogleAnalytics(eventName, parameters = {}) {
        if (typeof gtag !== 'undefined') {
            gtag('event', eventName, {
                ...parameters,
                zeeky_user_id: this.userId,
                zeeky_session_id: this.sessionId
            });
        }
    }
}

// Global instance
window.ZeekyAnalytics = new ZeekyAnalyticsEngine();

// Track performance when page loads
window.addEventListener('load', () => {
    setTimeout(() => {
        window.ZeekyAnalytics.trackPerformance();
    }, 1000);
});

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ZeekyAnalyticsEngine;
}
