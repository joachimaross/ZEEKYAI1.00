/**
 * Zeeky AI Voice Engine - Real Voice Integration
 * © 2025 Zeeky AI. All Rights Reserved.
 * Created by Joachima Ross Jr, CEO & Founder
 * Contact: zeekyai@hotmail.com | (773) 457-9882
 */

class ZeekyVoiceEngine {
    constructor() {
        this.isListening = false;
        this.isSpeaking = false;
        this.recognition = null;
        this.synthesis = window.speechSynthesis;
        this.voices = [];
        this.currentVoice = null;
        this.settings = {
            rate: 1.0,
            pitch: 1.0,
            volume: 1.0,
            language: 'en-US'
        };
        
        this.initializeVoiceRecognition();
        this.initializeVoiceSynthesis();
        this.setupVoiceCommands();
    }

    initializeVoiceRecognition() {
        if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
            const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            this.recognition = new SpeechRecognition();
            
            this.recognition.continuous = false;
            this.recognition.interimResults = false;
            this.recognition.lang = this.settings.language;
            this.recognition.maxAlternatives = 1;

            this.recognition.onstart = () => {
                this.isListening = true;
                this.onListeningStart();
            };

            this.recognition.onresult = (event) => {
                const transcript = event.results[0][0].transcript;
                const confidence = event.results[0][0].confidence;
                this.onSpeechRecognized(transcript, confidence);
            };

            this.recognition.onerror = (event) => {
                console.error('Speech recognition error:', event.error);
                this.onListeningError(event.error);
            };

            this.recognition.onend = () => {
                this.isListening = false;
                this.onListeningEnd();
            };
        } else {
            console.warn('Speech recognition not supported in this browser');
        }
    }

    initializeVoiceSynthesis() {
        if (this.synthesis) {
            this.synthesis.onvoiceschanged = () => {
                this.voices = this.synthesis.getVoices();
                this.selectBestVoice();
            };
            
            // Initial voice loading
            this.voices = this.synthesis.getVoices();
            this.selectBestVoice();
        }
    }

    selectBestVoice() {
        // Prefer female voices for Zeeky AI
        const preferredVoices = [
            'Microsoft Zira - English (United States)',
            'Google US English Female',
            'Samantha',
            'Victoria',
            'Karen',
            'Moira'
        ];

        for (const voiceName of preferredVoices) {
            const voice = this.voices.find(v => v.name.includes(voiceName.split(' - ')[0]));
            if (voice) {
                this.currentVoice = voice;
                return;
            }
        }

        // Fallback to any female voice
        const femaleVoice = this.voices.find(v => 
            v.name.toLowerCase().includes('female') || 
            v.name.toLowerCase().includes('woman') ||
            v.name.includes('Zira') ||
            v.name.includes('Samantha')
        );

        if (femaleVoice) {
            this.currentVoice = femaleVoice;
        } else if (this.voices.length > 0) {
            this.currentVoice = this.voices[0];
        }
    }

    setupVoiceCommands() {
        this.voiceCommands = {
            'hey zeeky': () => this.activateVoiceMode(),
            'zeeky listen': () => this.startListening(),
            'stop listening': () => this.stopListening(),
            'speak slower': () => this.adjustRate(0.8),
            'speak faster': () => this.adjustRate(1.2),
            'change voice': () => this.cycleVoice(),
            'mute zeeky': () => this.mute(),
            'unmute zeeky': () => this.unmute()
        };
    }

    startListening() {
        if (this.recognition && !this.isListening) {
            try {
                this.recognition.start();
                return true;
            } catch (error) {
                console.error('Error starting speech recognition:', error);
                return false;
            }
        }
        return false;
    }

    stopListening() {
        if (this.recognition && this.isListening) {
            this.recognition.stop();
        }
    }

    speak(text, options = {}) {
        return new Promise((resolve, reject) => {
            if (!this.synthesis) {
                reject(new Error('Speech synthesis not supported'));
                return;
            }

            // Stop any current speech
            this.synthesis.cancel();

            const utterance = new SpeechSynthesisUtterance(text);
            
            // Apply settings
            utterance.voice = this.currentVoice;
            utterance.rate = options.rate || this.settings.rate;
            utterance.pitch = options.pitch || this.settings.pitch;
            utterance.volume = options.volume || this.settings.volume;
            utterance.lang = options.language || this.settings.language;

            utterance.onstart = () => {
                this.isSpeaking = true;
                this.onSpeechStart(text);
            };

            utterance.onend = () => {
                this.isSpeaking = false;
                this.onSpeechEnd();
                resolve();
            };

            utterance.onerror = (event) => {
                this.isSpeaking = false;
                this.onSpeechError(event.error);
                reject(new Error(event.error));
            };

            this.synthesis.speak(utterance);
        });
    }

    stopSpeaking() {
        if (this.synthesis) {
            this.synthesis.cancel();
            this.isSpeaking = false;
        }
    }

    adjustRate(newRate) {
        this.settings.rate = Math.max(0.1, Math.min(2.0, newRate));
    }

    adjustPitch(newPitch) {
        this.settings.pitch = Math.max(0.0, Math.min(2.0, newPitch));
    }

    adjustVolume(newVolume) {
        this.settings.volume = Math.max(0.0, Math.min(1.0, newVolume));
    }

    cycleVoice() {
        if (this.voices.length > 1) {
            const currentIndex = this.voices.indexOf(this.currentVoice);
            const nextIndex = (currentIndex + 1) % this.voices.length;
            this.currentVoice = this.voices[nextIndex];
            
            this.speak(`Voice changed to ${this.currentVoice.name}`);
        }
    }

    mute() {
        this.settings.volume = 0;
        this.stopSpeaking();
    }

    unmute() {
        this.settings.volume = 1;
    }

    activateVoiceMode() {
        this.speak("Voice mode activated! I'm listening for your commands.");
        setTimeout(() => {
            this.startListening();
        }, 2000);
    }

    processVoiceCommand(transcript) {
        const lowerTranscript = transcript.toLowerCase();
        
        for (const [command, action] of Object.entries(this.voiceCommands)) {
            if (lowerTranscript.includes(command)) {
                action();
                return true;
            }
        }
        
        return false;
    }

    // Event handlers (to be overridden)
    onListeningStart() {
        console.log('Voice recognition started');
        this.updateUI('listening', true);
    }

    onListeningEnd() {
        console.log('Voice recognition ended');
        this.updateUI('listening', false);
    }

    onListeningError(error) {
        console.error('Voice recognition error:', error);
        this.updateUI('error', error);
    }

    onSpeechRecognized(transcript, confidence) {
        console.log('Speech recognized:', transcript, 'Confidence:', confidence);
        
        // Check for voice commands first
        if (!this.processVoiceCommand(transcript)) {
            // Send to AI for processing
            this.onUserSpeech(transcript, confidence);
        }
    }

    onSpeechStart(text) {
        console.log('Speech synthesis started:', text);
        this.updateUI('speaking', true);
    }

    onSpeechEnd() {
        console.log('Speech synthesis ended');
        this.updateUI('speaking', false);
    }

    onSpeechError(error) {
        console.error('Speech synthesis error:', error);
        this.updateUI('error', error);
    }

    onUserSpeech(transcript, confidence) {
        // Override this method to handle user speech
        console.log('User said:', transcript);
    }

    updateUI(event, data) {
        // Override this method to update UI
        const event_data = { event, data, timestamp: new Date().toISOString() };
        window.dispatchEvent(new CustomEvent('zeeky-voice-event', { detail: event_data }));
    }

    // Utility methods
    getAvailableVoices() {
        return this.voices.map(voice => ({
            name: voice.name,
            lang: voice.lang,
            gender: this.detectVoiceGender(voice.name)
        }));
    }

    detectVoiceGender(voiceName) {
        const femaleIndicators = ['female', 'woman', 'zira', 'samantha', 'victoria', 'karen', 'moira'];
        const maleIndicators = ['male', 'man', 'david', 'mark', 'alex'];
        
        const lowerName = voiceName.toLowerCase();
        
        if (femaleIndicators.some(indicator => lowerName.includes(indicator))) {
            return 'female';
        } else if (maleIndicators.some(indicator => lowerName.includes(indicator))) {
            return 'male';
        }
        
        return 'unknown';
    }

    getSettings() {
        return { ...this.settings };
    }

    updateSettings(newSettings) {
        this.settings = { ...this.settings, ...newSettings };
    }

    isSupported() {
        return !!(this.recognition && this.synthesis);
    }

    getStatus() {
        return {
            isListening: this.isListening,
            isSpeaking: this.isSpeaking,
            currentVoice: this.currentVoice ? this.currentVoice.name : null,
            voiceCount: this.voices.length,
            settings: this.settings,
            supported: this.isSupported()
        };
    }
}

// Global instance
window.ZeekyVoice = new ZeekyVoiceEngine();

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ZeekyVoiceEngine;
}
